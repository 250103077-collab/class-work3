package lab;

public final class PatternCost {
    interface DiscountStrategy { int apply(int price); }
    static final class NoDiscount      implements DiscountStrategy { public int apply(int p) { return p; } }
    static final class StudentDiscount implements DiscountStrategy { public int apply(int p) { return p - p / 10; } }
    static final class HolidayDiscount implements DiscountStrategy { public int apply(int p) { return p - p / 5; } }
    static final class VipDiscount     implements DiscountStrategy { public int apply(int p) { return p / 2; } }

    // Each method is its OWN call site, so the JIT keeps a separate type profile for each.
    static long monomorphicSite(DiscountStrategy[] arr, int n) {
        long s = 0;
        for (int i = 0; i < n; i++) s += arr[i & 1023].apply(i);   // only 1 type seen -> inlined
        return s;
    }
    static long megamorphicSite(DiscountStrategy[] arr, int n) {
        long s = 0;
        for (int i = 0; i < n; i++) s += arr[i & 1023].apply(i);   // 4 types seen -> vtable/itable lookup
        return s;
    }

    // ----------─ B) Decorator chain: pointer chasing ----------─
    interface Reader { int read(int x); }
    static final class BaseReader implements Reader { public int read(int x) { return x + 1; } }
    static final class LayerA implements Reader { final Reader in; LayerA(Reader in) { this.in = in; } public int read(int x) { return in.read(x) ^ 1; } }
    static final class LayerB implements Reader { final Reader in; LayerB(Reader in) { this.in = in; } public int read(int x) { return in.read(x) + 2; } }
    static final class LayerC implements Reader { final Reader in; LayerC(Reader in) { this.in = in; } public int read(int x) { return in.read(x) - 1; } }

    static Reader chain(int depth) {
        Reader r = new BaseReader();
        for (int i = 0; i < depth; i++) {
            r = switch (i % 3) { case 0 -> new LayerA(r); case 1 -> new LayerB(r); default -> new LayerC(r); };
        }
        return r;
    }
    static long callChain(Reader[] readers, int n) {
        long s = 0;
        for (int i = 0; i < n; i++) s += readers[i & 255].read(i);
        return s;
    }

    // ----------─ C) Adapter churn ----------─
    /** "Legacy" API with an incompatible signature. */
    static final class LegacyThermometer { double fahrenheit(long sensorId) { return 32 + (sensorId % 50) * 1.8; } }
    interface Thermometer { double celsius(long sensorId); }
    static final class ThermometerAdapter implements Thermometer {
        private final LegacyThermometer legacy;
        ThermometerAdapter(LegacyThermometer legacy) { this.legacy = legacy; }
        public double celsius(long id) { return (legacy.fahrenheit(id) - 32) / 1.8; }
    }
    static Thermometer escape;   // forces the per-call adapter to really escape -> real allocation

    public static void run() {
        Bench.header("Section 1 - Runtime cost of patterns");
        final int n = 20_000_000;

        // A
        DiscountStrategy[] mono = new DiscountStrategy[1024];
        DiscountStrategy[] mega = new DiscountStrategy[1024];
        DiscountStrategy[] all = { new NoDiscount(), new StudentDiscount(), new HolidayDiscount(), new VipDiscount() };
        for (int i = 0; i < 1024; i++) { mono[i] = all[1]; mega[i] = all[i & 3]; }
        Bench.compare("A) Strategy call site, " + n + " calls",
                "megamorphic (4 impls at one site)", () -> megamorphicSite(mega, n),
                "monomorphic (1 impl, JIT inlines)", () -> monomorphicSite(mono, n));

        // B - 256 independent chains so the objects are spread over the heap
        Reader[] deep = new Reader[256], flat = new Reader[256];
        for (int i = 0; i < 256; i++) { deep[i] = chain(8); flat[i] = new BaseReader(); }
        Bench.compare("B) Decorator, " + n + " calls",
                "8 nested decorators", () -> callChain(deep, n),
                "plain object (no wrappers)", () -> callChain(flat, n));

        // C
        LegacyThermometer legacy = new LegacyThermometer();
        Thermometer shared = new ThermometerAdapter(legacy);
        final int m = 10_000_000;
        Bench.compare("C) Adapter, " + m + " calls",
                "new Adapter(...) on every call", () -> {
                    double s = 0;
                    for (int i = 0; i < m; i++) { Thermometer t = new ThermometerAdapter(legacy); escape = t; s += t.celsius(i); }
                    return (long) s;
                },
                "one adapter, reused", () -> {
                    double s = 0;
                    for (int i = 0; i < m; i++) s += shared.celsius(i);
                    return (long) s;
                });
        System.out.println("   Tip: run with -Xlog:gc to see the Young GC pauses caused by the per-call adapter.");
    }
}
