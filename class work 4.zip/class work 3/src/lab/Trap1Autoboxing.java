package lab;

import java.util.function.ToIntFunction;
public final class Trap1Autoboxing {

    record Student(String name, int correct, int wrong) {}

    // [BAD] BAD: returns a boxed Integer -> heap allocation for values outside the -128..127 cache
    interface BoxedScoreCalculator<T> { Integer compute(T record); }

    // [GOOD] GOOD: returns a primitive int -> no allocation (equivalent to ToIntFunction<T>)
    interface ScoreCalculator<T> { int compute(T record); }

    public static void run() {
        Bench.header("Trap 1 - Autoboxing in generic interfaces");
        final int n = 5_000_000;
        Student[] students = new Student[1024];
        for (int i = 0; i < students.length; i++) students[i] = new Student("s" + i, 100 + i, i % 40);

        BoxedScoreCalculator<Student> boxed = s -> s.correct() * 4 - s.wrong() + 1000;
        ScoreCalculator<Student> primitive = s -> s.correct() * 4 - s.wrong() + 1000;
        ToIntFunction<Student> stdlib = s -> s.correct() * 4 - s.wrong() + 1000;

        Bench.compare("sum of " + n + " scores",
                "Integer compute(T)", () -> {
                    Integer total = 0;                       // boxed accumulator: classic mistake
                    for (int i = 0; i < n; i++) total += boxed.compute(students[i & 1023]);
                    return total;
                },
                "int compute(T)", () -> {
                    long total = 0;
                    for (int i = 0; i < n; i++) total += primitive.compute(students[i & 1023]);
                    return total;
                });
        long check = 0;
        for (int i = 0; i < 1024; i++) check += stdlib.applyAsInt(students[i]);
        System.out.println("   (ToIntFunction<T> from java.util.function gives the same result: " + check + ")");
    }
}
