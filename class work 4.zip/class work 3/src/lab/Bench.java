package lab;
public final class Bench {
    private Bench() {}
    public static volatile long sink;

    @FunctionalInterface
    public interface Task { long run(); }

    /** Runs the task with warm-up and returns the best time in milliseconds. */
    public static double measure(Task task, int warmups, int runs) {
        for (int i = 0; i < warmups; i++) sink += task.run();
        long best = Long.MAX_VALUE;
        for (int i = 0; i < runs; i++) {
            long t0 = System.nanoTime();
            sink += task.run();
            long t = System.nanoTime() - t0;
            if (t < best) best = t;
        }
        return best / 1_000_000.0;
    }

    public static void compare(String title, String badName, Task bad, String goodName, Task good) {
        double b = measure(bad, 5, 7);
        double g = measure(good, 5, 7);
        System.out.println("-- " + title);
        System.out.printf("   [BAD] %-38s %9.2f ms%n", badName, b);
        System.out.printf("   [GOOD] %-38s %9.2f ms   (x%.1f faster)%n", goodName, g, b / Math.max(g, 0.0001));
    }

    public static void header(String s) {
        System.out.println();
        System.out.println("===== " + s + " =====");
    }
}
