package lab;

import java.util.ArrayList;
import java.util.List;

/** Trap 3: String concatenation in loops - O(n^2) vs amortized O(n). */
public final class Trap3StringConcat {

    public static void run() {
        Bench.header("Trap 3 - String concatenation in loops");
        List<String> tokens = new ArrayList<>(20_000);
        for (int i = 0; i < 20_000; i++) tokens.add("tok" + i);

        Bench.compare("join " + tokens.size() + " tokens",
                "log += token + \", \"", () -> {
                    String log = "";
                    for (String token : tokens) { log += token + ", "; }
                    return log.length();
                },
                "StringBuilder(size * 16)", () -> {
                    StringBuilder log = new StringBuilder(tokens.size() * 16);
                    for (String token : tokens) { log.append(token).append(", "); }
                    return log.length();
                });
        System.out.println("   (String.join(\", \", tokens) is also fine - it uses a builder internally)");
    }
}
